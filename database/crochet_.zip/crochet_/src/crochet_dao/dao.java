package crochet_dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import crochet_model.model;

public class dao {
private static String URL ="db4free.net:3306/crochet";
private static String user ="hind_halima";
private static String password ="1d1c3a22";
private Connection connect = null;
private ResultSet resultSet = null;
private ArrayList resList = new ArrayList();
public ArrayList getmodel() throws Exception {
try {
String url="jdbc:mysql://" + URL;
connect = DriverManager.getConnection(url,user, password);
Statement statement = connect.createStatement();
resultSet = statement.executeQuery("select * from stitches");
while (resultSet.next()) {
String name = resultSet.getString("name");
String number = resultSet.getString("number");
resList.add(new model(name, number));}
return resList; }
catch (Exception e) {
throw e; } finally { close();
}}
private void close() {
try {
if (resultSet != null) {
resultSet.close();
}
if (connect != null) {
connect.close();}
} catch (Exception e) {
e.printStackTrace();}
}
}