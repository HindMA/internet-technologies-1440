package crochet_model;

public class model {
		private String Name1;
		private String Number1;
		
		public model(String name, String number) {
		Name1 = name;
		Number1 = number;
		}

		public String getName1() {
			return Name1;
		}

		public void setName1(String name1) {
			Name1 = name1;
		}

		public String getNumber1() {
			return Number1;
		}

		public void setNumber1(String number1) {
			Number1 = number1;
		}

		}